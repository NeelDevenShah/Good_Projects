# Speech-Emotion-Recognition-using-ML-and-DL
Speech Emotion Recognition System, abbreviated as SER System, is the act of attempting to recognize human emotion and affective states from speech. This is capitalizing on the fact that voice often reflects underlying emotion through tone and pitch. The speech emotion recognition system uses audio data. It takes a part of speech as input and then determines what emotions the speaker is speaking.
hiii!!!!!.
bye!!!!.
