Speech emotion recognition System
